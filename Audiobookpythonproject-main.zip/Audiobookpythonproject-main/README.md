# Audiobookpythonproject
#Skillzacodingcontest
Skillza Coding Project contest 
You can add any pdf for the computer to read i just put a sample pdf just for a test also you can specify which page you want the program too read
